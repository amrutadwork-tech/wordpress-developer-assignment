/**
 * BuyMore Dashboard behaviour:
 * - gender filter tabs, search, max-price filter
 * - favourite hearts (saved in localStorage)
 * - favourites slider
 * - mobile sidebar drawer, Dashboard/Website switch
 */
(function () {
	'use strict';

	var STORAGE_KEY = 'buymore_favs';

	function readFavs() {
		try {
			return JSON.parse(window.localStorage.getItem(STORAGE_KEY)) || [];
		} catch (e) {
			return [];
		}
	}

	function writeFavs(list) {
		try {
			window.localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
		} catch (e) { /* storage unavailable: ignore */ }
	}

	function init(app) {
		var items = Array.prototype.slice.call(app.querySelectorAll('.bm-item'));
		var tabs = app.querySelectorAll('.bm-tabs button');
		var panel = app.querySelector('[data-bm-panel]');
		var searchInput = app.querySelector('[data-bm-search]');
		var priceInput = app.querySelector('[data-bm-price]');
		var priceOut = app.querySelector('[data-bm-price-out]');
		var filtersBtn = app.querySelector('[data-bm-filters]');
		var emptyMsg = app.querySelector('[data-bm-empty]');

		var state = { gender: 'all', query: '', maxPrice: priceInput ? parseFloat(priceInput.max) : Infinity };

		/* ----- filtering ----- */
		function applyFilters() {
			var visible = 0;

			items.forEach(function (el) {
				var genders = (el.getAttribute('data-gender') || '').split(' ').filter(Boolean);
				var price = parseFloat(el.getAttribute('data-price')) || 0;
				var title = el.getAttribute('data-title') || '';

				var okGender = state.gender === 'all' || genders.length === 0 || genders.indexOf(state.gender) !== -1;
				var okQuery = !state.query || title.indexOf(state.query) !== -1;
				var okPrice = price === 0 || price <= state.maxPrice;

				var show = okGender && okQuery && okPrice;
				el.hidden = !show;
				if (show) { visible++; }
			});

			if (emptyMsg) { emptyMsg.hidden = visible > 0; }

			if (filtersBtn && priceInput) {
				filtersBtn.classList.toggle('has-filter', state.maxPrice < parseFloat(priceInput.max));
			}
		}

		tabs.forEach(function (tab) {
			tab.addEventListener('click', function () {
				tabs.forEach(function (t) { t.classList.remove('is-active'); });
				tab.classList.add('is-active');
				state.gender = tab.getAttribute('data-filter');
				applyFilters();
			});
		});

		function togglePanel(focusSearch) {
			if (!panel) { return; }
			var open = panel.hidden;
			panel.hidden = !open;
			if (filtersBtn) { filtersBtn.setAttribute('aria-expanded', String(open)); }
			if (open && focusSearch && searchInput) { searchInput.focus(); }
		}

		var filterToggle = app.querySelector('[data-bm-filters]');
		var searchToggle = app.querySelector('[data-bm-search-toggle]');
		if (filterToggle) { filterToggle.addEventListener('click', function () { togglePanel(false); }); }
		if (searchToggle) { searchToggle.addEventListener('click', function () { togglePanel(true); }); }

		if (searchInput) {
			searchInput.addEventListener('input', function () {
				state.query = searchInput.value.trim().toLowerCase();
				applyFilters();
			});
		}

		if (priceInput) {
			priceInput.addEventListener('input', function () {
				state.maxPrice = parseFloat(priceInput.value);
				if (priceOut) { priceOut.textContent = priceInput.value; }
				applyFilters();
			});
		}

		/* ----- favourite hearts ----- */
		var favs = readFavs();
		app.querySelectorAll('.bm-heart').forEach(function (btn) {
			var id = btn.getAttribute('data-fav-id');
			if (favs.indexOf(id) !== -1) { btn.classList.add('is-on'); }

			btn.addEventListener('click', function () {
				var list = readFavs();
				var idx = list.indexOf(id);
				if (idx === -1) { list.push(id); } else { list.splice(idx, 1); }
				writeFavs(list);
				btn.classList.toggle('is-on', idx === -1);
			});
		});

		/* ----- favourites slider ----- */
		var fav = app.querySelector('[data-bm-fav]');
		if (fav) {
			var thumbs = Array.prototype.slice.call(fav.querySelectorAll('.bm-fav__thumb'));
			var perPage = 2;
			var page = 0;
			var pages = Math.max(1, Math.ceil(thumbs.length / perPage));

			var renderSlider = function () {
				thumbs.forEach(function (el, i) {
					el.hidden = Math.floor(i / perPage) !== page;
				});
			};

			fav.querySelectorAll('.bm-fav__nav').forEach(function (btn) {
				btn.addEventListener('click', function () {
					var dir = parseInt(btn.getAttribute('data-dir'), 10);
					page = (page + dir + pages) % pages;
					renderSlider();
				});
			});
			renderSlider();
		}

		/* ----- Dashboard / Website switch ----- */
		var switchBtns = app.querySelectorAll('.bm-switch button');
		switchBtns.forEach(function (btn) {
			btn.addEventListener('click', function () {
				switchBtns.forEach(function (b) { b.classList.remove('is-active'); });
				btn.classList.add('is-active');
			});
		});

		/* ----- sidebar nav active state ----- */
		var navLinks = app.querySelectorAll('.bm-nav a');
		navLinks.forEach(function (link) {
			link.addEventListener('click', function (e) {
				if (link.getAttribute('href') === '#') { e.preventDefault(); }
				navLinks.forEach(function (l) { l.classList.remove('is-active'); });
				link.classList.add('is-active');
				app.classList.remove('is-open');
			});
		});

		/* ----- mobile drawer ----- */
		var openBtn = app.querySelector('[data-bm-open]');
		if (openBtn) { openBtn.addEventListener('click', function () { app.classList.add('is-open'); }); }
		app.querySelectorAll('[data-bm-close]').forEach(function (el) {
			el.addEventListener('click', function () { app.classList.remove('is-open'); });
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') { app.classList.remove('is-open'); }
		});

		applyFilters();
	}

	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('[data-bm-app]').forEach(init);
	});
})();
