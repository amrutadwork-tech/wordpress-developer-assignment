<?php
/**
 * Full page template: renders the page content (which holds the dashboard shortcode)
 * without theme header/footer, so editors can still add shortcode options or extra
 * blocks from the normal page editor.
 *
 * @package BuyMore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'buymore-fullpage' ); ?>>
<?php wp_body_open(); ?>
<?php
while ( have_posts() ) {
	the_post();
	if ( has_shortcode( get_the_content(), 'buymore_dashboard' ) ) {
		the_content();
	} else {
		// Template chosen but shortcode removed: still show the dashboard.
		echo BuyMore_Shortcode::render(); // phpcs:ignore WordPress.Security.EscapeOutput
	}
}
?>
<?php wp_footer(); ?>
</body>
</html>
