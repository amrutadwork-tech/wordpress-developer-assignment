<?php
/**
 * Dashboard markup.
 *
 * Variables: $settings (array), $cards (array grouped by slot),
 * $products (array), $favourites (array).
 *
 * @package BuyMore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Small inline SVG icon set (stroke icons, inherit currentColor).
 */
$bm_icon = static function ( $name ) {
	$paths = array(
		'spark'   => '<path d="M12 3l2.2 5.8L20 11l-5.8 2.2L12 19l-2.2-5.8L4 11l5.8-2.2z"/>',
		'compass' => '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
		'shoe'    => '<path d="M4 8h6l2 3h6a2 2 0 012 2v3H4z"/>',
		'gift'    => '<rect x="4" y="9" width="16" height="11" rx="1"/><path d="M12 9v11M4 13h16M12 9c-2-4-6-3-5 0M12 9c2-4 6-3 5 0"/>',
		'bulb'    => '<path d="M9 18h6M10 21h4M12 3a6 6 0 00-3 11v2h6v-2a6 6 0 00-3-11z"/>',
		'plus'    => '<path d="M12 5v14M5 12h14"/>',
		'logout'  => '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>',
		'search'  => '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/>',
		'cart'    => '<rect x="5" y="8" width="14" height="12" rx="2"/><path d="M9 8V6a3 3 0 016 0v2"/>',
		'heart'   => '<path d="M12 20s-7-4.4-7-10a4 4 0 017-2.6A4 4 0 0119 10c0 5.600-7 10-7 10z"/>',
		'arrow'   => '<path d="M8 16l8-8M9 8h7v7"/>',
		'left'    => '<path d="M14 6l-6 6 6 6"/>',
		'right'   => '<path d="M10 6l6 6-6 6"/>',
		'filter'  => '<path d="M4 7h16M7 12h10M10 17h4"/>',
		'menu'    => '<path d="M4 7h16M4 12h16M4 17h16"/>',
		'close'   => '<path d="M6 6l12 12M18 6L6 18"/>',
		'all'     => '<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M5 15V6a1 1 0 011-1h9"/>',
		'men'     => '<circle cx="10" cy="14" r="4"/><path d="M13 11l6-6M14 5h5v5"/>',
		'women'   => '<circle cx="12" cy="9" r="4"/><path d="M12 13v7M9 17h6"/>',
	);
	$d = isset( $paths[ $name ] ) ? $paths[ $name ] : '';
	return '<svg class="bm-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>'; // phpcs:ignore
};

$bm_menu_icons = array( 'spark', 'compass', 'shoe', 'gift', 'bulb' );
$bm_menu       = BuyMore_Settings::parse_lines( $settings['menu'] );
$bm_quick      = BuyMore_Settings::parse_lines( $settings['quick'] );
$bm_last       = BuyMore_Settings::parse_lines( $settings['last_orders'] );
$bm_max_price  = 0;
foreach ( $products as $bm_p ) {
	$bm_max_price = max( $bm_max_price, (float) $bm_p['amount'] );
}
$bm_max_price = (int) ceil( $bm_max_price );

/**
 * Renders a single product card.
 */
$bm_render_product = static function ( $p ) use ( $bm_icon ) {
	?>
	<article class="bm-item bm-product" data-gender="<?php echo esc_attr( $p['gender'] ); ?>" data-price="<?php echo esc_attr( $p['amount'] ); ?>" data-title="<?php echo esc_attr( strtolower( $p['title'] ) ); ?>">
		<?php if ( ! empty( $p['edit'] ) ) : ?>
			<a class="bm-edit" href="<?php echo esc_url( $p['edit'] ); ?>"><?php esc_html_e( 'Edit', 'buymore' ); ?></a>
		<?php endif; ?>
		<button type="button" class="bm-heart" aria-label="<?php esc_attr_e( 'Add to favourites', 'buymore' ); ?>" data-fav-id="p<?php echo (int) $p['id']; ?>"><?php echo $bm_icon( 'heart' ); // phpcs:ignore ?></button>
		<?php if ( $p['colors'] ) : ?>
			<div class="bm-dots">
				<?php foreach ( $p['colors'] as $color ) : ?>
					<span style="background:<?php echo esc_attr( $color ); ?>"></span>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<div class="bm-product__img"><img src="<?php echo esc_url( $p['image'] ); ?>" alt="<?php echo esc_attr( $p['title'] ); ?>" loading="lazy"></div>
		<div class="bm-product__info">
			<div>
				<?php if ( $p['label'] ) : ?>
					<small><?php echo esc_html( $p['label'] ); ?></small>
				<?php endif; ?>
				<h3><?php echo esc_html( $p['title'] ); ?></h3>
			</div>
			<?php if ( $p['price'] ) : ?>
				<a class="bm-price" href="<?php echo esc_url( $p['link'] ? $p['link'] : '#' ); ?>"><?php echo esc_html( $p['price'] ); ?></a>
			<?php endif; ?>
		</div>
	</article>
	<?php
};

/**
 * Renders a promo card for any slot.
 */
$bm_render_card = static function ( $c, $slot ) use ( $bm_icon ) {
	$style = sprintf( '--bm-bg:%s;--bm-fg:%s;', $c['bg'], $c['fg'] );
	?>
	<article class="bm-item bm-card bm-card--<?php echo esc_attr( $slot ); ?>" style="<?php echo esc_attr( $style ); ?>" data-gender="<?php echo esc_attr( $c['gender'] ); ?>" data-price="0" data-title="<?php echo esc_attr( strtolower( $c['title'] ) ); ?>">
		<?php if ( ! empty( $c['edit'] ) ) : ?>
			<a class="bm-edit" href="<?php echo esc_url( $c['edit'] ); ?>"><?php esc_html_e( 'Edit', 'buymore' ); ?></a>
		<?php endif; ?>
		<img class="bm-card__img" src="<?php echo esc_url( $c['image'] ); ?>" alt="" loading="lazy">
		<?php if ( in_array( $slot, array( 'feature', 'wide' ), true ) ) : ?>
			<a class="bm-card__arrow" href="<?php echo esc_url( $c['link'] ? $c['link'] : '#' ); ?>" aria-label="<?php echo esc_attr( $c['title'] ); ?>"><?php echo $bm_icon( 'arrow' ); // phpcs:ignore ?></a>
		<?php endif; ?>
		<?php if ( 'portrait' === $slot ) : ?>
			<button type="button" class="bm-heart" aria-label="<?php esc_attr_e( 'Add to favourites', 'buymore' ); ?>" data-fav-id="c<?php echo (int) $c['id']; ?>"><?php echo $bm_icon( 'heart' ); // phpcs:ignore ?></button>
		<?php endif; ?>
		<div class="bm-card__body">
			<?php if ( 'portrait' !== $slot ) : ?>
				<h3><?php echo esc_html( $c['title'] ); ?></h3>
			<?php endif; ?>
			<?php if ( $c['subtitle'] ) : ?>
				<p><?php echo esc_html( $c['subtitle'] ); ?></p>
			<?php endif; ?>
			<?php if ( $c['button'] ) : ?>
				<a class="bm-btn" href="<?php echo esc_url( $c['link'] ? $c['link'] : '#' ); ?>"><?php echo esc_html( $c['button'] ); ?></a>
			<?php endif; ?>
		</div>
	</article>
	<?php
};
?>
<div class="bm-stage">
	<div class="bm-app" data-bm-app>

		<div class="bm-backdrop" data-bm-close></div>

		<aside class="bm-sidebar" id="bm-sidebar">
			<div class="bm-sidebar__top">
				<div class="bm-brand"><?php echo esc_html( $settings['brand'] ); ?><i></i></div>
				<button type="button" class="bm-iconbtn bm-close" data-bm-close aria-label="<?php esc_attr_e( 'Close menu', 'buymore' ); ?>"><?php echo $bm_icon( 'close' ); // phpcs:ignore ?></button>
			</div>

			<nav class="bm-nav" aria-label="<?php esc_attr_e( 'Dashboard menu', 'buymore' ); ?>">
				<?php foreach ( $bm_menu as $i => $item ) : ?>
					<a href="<?php echo esc_url( $item['url'] ); ?>" class="<?php echo $item['active'] ? 'is-active' : ''; ?>">
						<?php echo $bm_icon( $bm_menu_icons[ $i % count( $bm_menu_icons ) ] ); // phpcs:ignore ?>
						<span><?php echo esc_html( $item['label'] ); ?></span>
					</a>
				<?php endforeach; ?>
			</nav>

			<?php if ( $bm_quick ) : ?>
				<div class="bm-side-block">
					<p class="bm-side-title"><?php esc_html_e( 'Quick actions', 'buymore' ); ?></p>
					<?php foreach ( $bm_quick as $item ) : ?>
						<a class="bm-quick" href="<?php echo esc_url( $item['url'] ); ?>"><?php echo $bm_icon( 'plus' ); // phpcs:ignore ?><span><?php echo esc_html( $item['label'] ); ?></span></a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( $bm_last ) : ?>
				<div class="bm-side-block">
					<p class="bm-side-title"><?php esc_html_e( 'Last orders', 'buymore' ); ?> <b><?php echo esc_html( $settings['orders'] ); ?></b></p>
					<?php foreach ( $bm_last as $i => $item ) : ?>
						<a class="bm-last" href="<?php echo esc_url( $item['url'] ); ?>">
							<span class="bm-last__thumb bm-last__thumb--<?php echo (int) ( $i % 3 ); ?>"></span>
							<span class="bm-last__txt"><?php echo esc_html( $item['label'] ); ?> <em><?php esc_html_e( 'view order', 'buymore' ); ?></em></span>
						</a>
					<?php endforeach; ?>
					<a class="bm-seeall" href="#"><?php esc_html_e( 'See all', 'buymore' ); ?></a>
				</div>
			<?php endif; ?>

			<a class="bm-logout" href="<?php echo esc_url( $settings['logout_url'] ); ?>"><?php echo $bm_icon( 'logout' ); // phpcs:ignore ?><span><?php echo esc_html( $settings['logout_label'] ); ?></span></a>
		</aside>

		<div class="bm-main">
			<header class="bm-topbar">
				<button type="button" class="bm-iconbtn bm-burger" data-bm-open aria-label="<?php esc_attr_e( 'Open menu', 'buymore' ); ?>" aria-controls="bm-sidebar"><?php echo $bm_icon( 'menu' ); // phpcs:ignore ?></button>

				<div class="bm-orders">
					<strong><?php echo esc_html( $settings['orders'] ); ?></strong>
					<span>Orders<br><?php echo esc_html( $settings['orders_label'] ); ?></span>
				</div>

				<div class="bm-switch" role="tablist">
					<button type="button" class="is-active" role="tab"><?php esc_html_e( 'Dashboard', 'buymore' ); ?></button>
					<button type="button" role="tab"><?php esc_html_e( 'Website', 'buymore' ); ?></button>
				</div>

				<div class="bm-topright">
					<button type="button" class="bm-cart"><?php echo $bm_icon( 'cart' ); // phpcs:ignore ?><span><?php echo esc_html( $settings['cart_label'] ); ?></span></button>
					<div class="bm-avatars" aria-hidden="true"><i></i><i></i><i></i><em><?php echo esc_html( $settings['cart_extra'] ); ?></em></div>
					<div class="bm-user">
						<span class="bm-user__avatar"><?php echo esc_html( mb_strtoupper( mb_substr( $settings['user_name'], 0, 1 ) ) ); ?></span>
						<span class="bm-user__name"><?php echo esc_html( $settings['user_name'] ); ?></span>
					</div>
				</div>
			</header>

			<section class="bm-explore">
				<div class="bm-explore__head">
					<h2><?php echo esc_html( $settings['explore_title'] ); ?></h2>

					<div class="bm-tabs" role="tablist">
						<button type="button" class="is-active" data-filter="all"><?php echo $bm_icon( 'all' ); // phpcs:ignore ?><span><?php esc_html_e( 'All', 'buymore' ); ?></span></button>
						<button type="button" data-filter="men"><?php echo $bm_icon( 'men' ); // phpcs:ignore ?><span><?php esc_html_e( 'Men', 'buymore' ); ?></span></button>
						<button type="button" data-filter="women"><?php echo $bm_icon( 'women' ); // phpcs:ignore ?><span><?php esc_html_e( 'Women', 'buymore' ); ?></span></button>
					</div>

					<div class="bm-tools">
						<button type="button" class="bm-filters" data-bm-filters aria-expanded="false"><span><?php esc_html_e( 'Filters', 'buymore' ); ?></span><?php echo $bm_icon( 'filter' ); // phpcs:ignore ?><i class="bm-filters__dot"></i></button>
						<button type="button" class="bm-iconbtn" data-bm-search-toggle aria-label="<?php esc_attr_e( 'Search', 'buymore' ); ?>"><?php echo $bm_icon( 'search' ); // phpcs:ignore ?></button>
					</div>
				</div>

				<div class="bm-panel" data-bm-panel hidden>
					<label class="bm-panel__search">
						<?php echo $bm_icon( 'search' ); // phpcs:ignore ?>
						<input type="search" data-bm-search placeholder="<?php esc_attr_e( 'Search items…', 'buymore' ); ?>">
					</label>
					<?php if ( $bm_max_price > 0 ) : ?>
						<label class="bm-panel__price">
							<span><?php esc_html_e( 'Max price', 'buymore' ); ?>: <b data-bm-price-out><?php echo (int) $bm_max_price; ?></b></span>
							<input type="range" min="0" max="<?php echo (int) $bm_max_price; ?>" value="<?php echo (int) $bm_max_price; ?>" data-bm-price>
						</label>
					<?php endif; ?>
				</div>

				<div class="bm-grid" data-bm-grid>
					<?php
					foreach ( array( 'banner' ) as $slot ) {
						foreach ( isset( $cards[ $slot ] ) ? $cards[ $slot ] : array() as $card ) {
							$bm_render_card( $card, $slot );
						}
					}
					foreach ( $products as $product ) {
						$bm_render_product( $product );
					}
					foreach ( array( 'feature', 'portrait' ) as $slot ) {
						foreach ( isset( $cards[ $slot ] ) ? $cards[ $slot ] : array() as $card ) {
							$bm_render_card( $card, $slot );
						}
					}
					?>

					<?php if ( $favourites ) : ?>
						<article class="bm-item bm-fav" data-bm-fav data-gender="" data-price="0" data-title="favourites">
							<div class="bm-fav__head">
								<span>Favourites</span>
								<button type="button" class="bm-fav__nav" data-dir="-1" aria-label="<?php esc_attr_e( 'Previous', 'buymore' ); ?>"><?php echo $bm_icon( 'left' ); // phpcs:ignore ?></button>
								<button type="button" class="bm-fav__nav" data-dir="1" aria-label="<?php esc_attr_e( 'Next', 'buymore' ); ?>"><?php echo $bm_icon( 'right' ); // phpcs:ignore ?></button>
							</div>
							<div class="bm-fav__track">
								<?php foreach ( $favourites as $i => $fav ) : ?>
									<a class="bm-fav__thumb bm-fav__thumb--<?php echo (int) ( $i % 2 ); ?>" href="<?php echo esc_url( $fav['link'] ? $fav['link'] : '#' ); ?>" title="<?php echo esc_attr( $fav['title'] ); ?>">
										<img src="<?php echo esc_url( $fav['image'] ); ?>" alt="<?php echo esc_attr( $fav['title'] ); ?>" loading="lazy">
									</a>
								<?php endforeach; ?>
							</div>
							<a class="bm-btn bm-fav__all" href="#"><?php esc_html_e( 'See All', 'buymore' ); ?></a>
						</article>
					<?php endif; ?>

					<?php
					foreach ( isset( $cards['wide'] ) ? $cards['wide'] : array() as $card ) {
						$bm_render_card( $card, 'wide' );
					}
					?>
				</div>

				<p class="bm-empty" data-bm-empty hidden><?php esc_html_e( 'Nothing matches your filters.', 'buymore' ); ?></p>
			</section>
		</div>
	</div>
</div>
