<?php
/**
 * Activation routine: seeds demo content and creates the dashboard page.
 *
 * @package BuyMore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BuyMore_Installer {

	public static function activate() {
		// CPTs/taxonomy must exist before inserting terms and posts.
		BuyMore_Post_Types::register();

		self::seed_terms();

		if ( ! get_option( 'buymore_seeded' ) ) {
			self::seed_cards();
			self::seed_products();
			self::create_page();
			update_option( 'buymore_seeded', '1' );
		}

		flush_rewrite_rules();
	}

	private static function seed_terms() {
		foreach ( array( 'Men' => 'men', 'Women' => 'women' ) as $name => $slug ) {
			if ( ! term_exists( $slug, 'bm_gender' ) ) {
				wp_insert_term( $name, 'bm_gender', array( 'slug' => $slug ) );
			}
		}
	}

	private static function insert( $type, $title, $order, $meta, $gender = '' ) {
		$id = wp_insert_post(
			array(
				'post_type'   => $type,
				'post_title'  => $title,
				'post_status' => 'publish',
				'menu_order'  => $order,
			)
		);
		if ( ! $id || is_wp_error( $id ) ) {
			return;
		}
		foreach ( $meta as $key => $value ) {
			update_post_meta( $id, $key, $value );
		}
		if ( $gender ) {
			wp_set_object_terms( $id, $gender, 'bm_gender' );
		}
	}

	private static function seed_cards() {
		$cards = array(
			array( 'GET UP TO 50% OFF', 1, 'banner', '', 'Get Discount', '#b9efc9', '#111111', 'women' ),
			array( 'Winter\'s weekend', 2, 'feature', 'keep it casual', '', '#fde58f', '#111111', 'women' ),
			array( 'Avail Offers', 3, 'portrait', '', 'Avail Offers', '#e6e6e6', '#111111', 'women' ),
			array( 'Bring Bold Fashion', 4, 'wide', 'Layers on Layers', '', '#eef3f1', '#111111', 'men' ),
		);
		foreach ( $cards as $c ) {
			self::insert(
				'bm_card',
				$c[0],
				$c[1],
				array(
					'_bm_slot'     => $c[2],
					'_bm_subtitle' => $c[3],
					'_bm_button'   => $c[4],
					'_bm_link'     => '#',
					'_bm_bg'       => $c[5],
					'_bm_text'     => $c[6],
				),
				$c[7]
			);
		}
	}

	private static function seed_products() {
		$products = array(
			array( 'WMX Rubber Zebra sandal', 1, '$36', 'Our Picks', '#f28ec7,#ffd23f', true, 'women' ),
			array( 'Supper Skiny jogger in brown', 2, '$89', 'Your Choice', '#ffd23f,#111111', true, 'men' ),
			array( 'Colour Block Hoodie', 3, '$59', 'New In', '#ff9f80,#7ec8a9', true, 'men' ),
			array( 'Green Knit Sweater', 4, '$49', 'Trending', '#9be39b,#ffffff', true, 'women' ),
		);
		foreach ( $products as $p ) {
			self::insert(
				'bm_product',
				$p[0],
				$p[1],
				array(
					'_bm_price'     => $p[2],
					'_bm_label'     => $p[3],
					'_bm_colors'    => $p[4],
					'_bm_link'      => '#',
					'_bm_favourite' => $p[5] ? '1' : '',
				),
				$p[6]
			);
		}
	}

	private static function create_page() {
		$existing = get_page_by_path( 'buymore-dashboard' );
		if ( $existing ) {
			return;
		}
		$page_id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_title'   => 'BuyMore Dashboard',
				'post_name'    => 'buymore-dashboard',
				'post_status'  => 'publish',
				'post_content' => '[buymore_dashboard]',
			)
		);
		if ( $page_id && ! is_wp_error( $page_id ) ) {
			update_post_meta( $page_id, '_wp_page_template', BuyMore_Shortcode::TEMPLATE_SLUG );
		}
	}
}
