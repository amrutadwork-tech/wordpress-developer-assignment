<?php
/**
 * Custom post types (cards, products), gender taxonomy and meta boxes.
 *
 * @package BuyMore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BuyMore_Post_Types {

	const NONCE = 'buymore_meta_nonce';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_boxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ), 10, 2 );
		add_filter( 'manage_bm_card_posts_columns', array( __CLASS__, 'card_columns' ) );
		add_action( 'manage_bm_card_posts_custom_column', array( __CLASS__, 'card_column_content' ), 10, 2 );
		add_filter( 'manage_bm_product_posts_columns', array( __CLASS__, 'product_columns' ) );
		add_action( 'manage_bm_product_posts_custom_column', array( __CLASS__, 'product_column_content' ), 10, 2 );
	}

	/* ---------- Registration ---------- */

	public static function register() {
		register_post_type(
			'bm_card',
			array(
				'labels'       => array(
					'name'          => __( 'BuyMore Cards', 'buymore' ),
					'singular_name' => __( 'Card', 'buymore' ),
					'add_new_item'  => __( 'Add New Card', 'buymore' ),
					'edit_item'     => __( 'Edit Card', 'buymore' ),
					'menu_name'     => __( 'BuyMore', 'buymore' ),
					'all_items'     => __( 'Promo Cards', 'buymore' ),
				),
				'public'       => false,
				'show_ui'      => true,
				'menu_icon'    => 'dashicons-store',
				'menu_position'=> 26,
				'supports'     => array( 'title', 'thumbnail', 'page-attributes' ),
			)
		);

		register_post_type(
			'bm_product',
			array(
				'labels'       => array(
					'name'          => __( 'BuyMore Products', 'buymore' ),
					'singular_name' => __( 'Product', 'buymore' ),
					'add_new_item'  => __( 'Add New Product', 'buymore' ),
					'edit_item'     => __( 'Edit Product', 'buymore' ),
					'all_items'     => __( 'Products', 'buymore' ),
				),
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => 'edit.php?post_type=bm_card',
				'supports'     => array( 'title', 'thumbnail', 'page-attributes' ),
			)
		);

		register_taxonomy(
			'bm_gender',
			array( 'bm_card', 'bm_product' ),
			array(
				'labels'            => array(
					'name'          => __( 'Gender', 'buymore' ),
					'singular_name' => __( 'Gender', 'buymore' ),
				),
				'public'            => false,
				'show_ui'           => true,
				'show_admin_column' => true,
				'hierarchical'      => true,
			)
		);
	}

	/* ---------- Field definitions ---------- */

	public static function fields( $post_type ) {
		if ( 'bm_card' === $post_type ) {
			return array(
				'_bm_slot'     => array(
					'label'   => __( 'Card style / slot', 'buymore' ),
					'type'    => 'select',
					'options' => self::slot_options(),
					'help'    => __( 'Decides the layout position and style of the card.', 'buymore' ),
				),
				'_bm_subtitle' => array( 'label' => __( 'Subtitle', 'buymore' ), 'type' => 'text' ),
				'_bm_button'   => array( 'label' => __( 'Button text', 'buymore' ), 'type' => 'text' ),
				'_bm_link'     => array( 'label' => __( 'Link URL', 'buymore' ), 'type' => 'url' ),
				'_bm_bg'       => array( 'label' => __( 'Background colour', 'buymore' ), 'type' => 'color', 'default' => '#ffffff' ),
				'_bm_text'     => array( 'label' => __( 'Text colour', 'buymore' ), 'type' => 'color', 'default' => '#111111' ),
			);
		}
		return array(
			'_bm_price'     => array( 'label' => __( 'Price (e.g. $36)', 'buymore' ), 'type' => 'text' ),
			'_bm_label'     => array( 'label' => __( 'Small label (e.g. Our Picks)', 'buymore' ), 'type' => 'text' ),
			'_bm_colors'    => array(
				'label' => __( 'Colour dots', 'buymore' ),
				'type'  => 'text',
				'help'  => __( 'Comma separated hex colours, e.g. #f28ec7,#ffd23f', 'buymore' ),
			),
			'_bm_link'      => array( 'label' => __( 'Link URL', 'buymore' ), 'type' => 'url' ),
			'_bm_favourite' => array( 'label' => __( 'Show in Favourites slider', 'buymore' ), 'type' => 'checkbox' ),
		);
	}

	public static function slot_options() {
		return array(
			'banner'   => __( 'Banner (top, wide, image behind text)', 'buymore' ),
			'feature'  => __( 'Feature (text left, image right)', 'buymore' ),
			'portrait' => __( 'Portrait (full image + button)', 'buymore' ),
			'wide'     => __( 'Wide (bottom, text left, image right)', 'buymore' ),
		);
	}

	/* ---------- Meta boxes ---------- */

	public static function add_meta_boxes() {
		foreach ( array( 'bm_card', 'bm_product' ) as $type ) {
			add_meta_box(
				'buymore_details',
				__( 'Display details', 'buymore' ),
				array( __CLASS__, 'render_meta_box' ),
				$type,
				'normal',
				'high'
			);
		}
	}

	public static function render_meta_box( $post ) {
		wp_nonce_field( 'buymore_save_' . $post->ID, self::NONCE );
		echo '<p class="description">' . esc_html__( 'Set the Featured Image (right sidebar) to change the picture. Use "Order" in Page Attributes to control the sequence.', 'buymore' ) . '</p>';
		echo '<table class="form-table" role="presentation">';

		foreach ( self::fields( $post->post_type ) as $key => $field ) {
			$value = get_post_meta( $post->ID, $key, true );
			if ( '' === $value && isset( $field['default'] ) ) {
				$value = $field['default'];
			}
			echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $field['label'] ) . '</label></th><td>';

			switch ( $field['type'] ) {
				case 'select':
					echo '<select id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">';
					foreach ( $field['options'] as $opt => $text ) {
						printf( '<option value="%s"%s>%s</option>', esc_attr( $opt ), selected( $value, $opt, false ), esc_html( $text ) );
					}
					echo '</select>';
					break;
				case 'checkbox':
					printf( '<input type="checkbox" id="%1$s" name="%1$s" value="1"%2$s>', esc_attr( $key ), checked( $value, '1', false ) );
					break;
				case 'color':
					printf( '<input type="color" id="%1$s" name="%1$s" value="%2$s">', esc_attr( $key ), esc_attr( $value ) );
					break;
				default:
					printf( '<input type="%1$s" class="regular-text" id="%2$s" name="%2$s" value="%3$s">', 'url' === $field['type'] ? 'url' : 'text', esc_attr( $key ), esc_attr( $value ) );
			}

			if ( ! empty( $field['help'] ) ) {
				echo '<p class="description">' . esc_html( $field['help'] ) . '</p>';
			}
			echo '</td></tr>';
		}
		echo '</table>';
	}

	public static function save( $post_id, $post ) {
		if ( ! in_array( $post->post_type, array( 'bm_card', 'bm_product' ), true ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE ] ) ), 'buymore_save_' . $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( self::fields( $post->post_type ) as $key => $field ) {
			$raw = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

			switch ( $field['type'] ) {
				case 'url':
					$value = esc_url_raw( $raw );
					break;
				case 'color':
					$value = (string) sanitize_hex_color( $raw );
					break;
				case 'checkbox':
					$value = $raw ? '1' : '';
					break;
				case 'select':
					$value = array_key_exists( $raw, $field['options'] ) ? $raw : key( $field['options'] );
					break;
				default:
					$value = sanitize_text_field( $raw );
			}
			update_post_meta( $post_id, $key, $value );
		}
	}

	/* ---------- Admin list columns ---------- */

	public static function card_columns( $columns ) {
		$columns['bm_slot'] = __( 'Slot', 'buymore' );
		return $columns;
	}

	public static function card_column_content( $column, $post_id ) {
		if ( 'bm_slot' === $column ) {
			$slots = self::slot_options();
			$slot  = get_post_meta( $post_id, '_bm_slot', true );
			echo esc_html( isset( $slots[ $slot ] ) ? $slots[ $slot ] : '—' );
		}
	}

	public static function product_columns( $columns ) {
		$columns['bm_price'] = __( 'Price', 'buymore' );
		return $columns;
	}

	public static function product_column_content( $column, $post_id ) {
		if ( 'bm_price' === $column ) {
			echo esc_html( get_post_meta( $post_id, '_bm_price', true ) );
		}
	}
}
