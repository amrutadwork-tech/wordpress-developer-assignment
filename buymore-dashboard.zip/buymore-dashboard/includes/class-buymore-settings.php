<?php
/**
 * Global dashboard settings (brand, orders counter, sidebar menus, user).
 *
 * @package BuyMore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BuyMore_Settings {

	const OPTION = 'buymore_settings';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
	}

	/**
	 * Default values, also used as fallback for empty options.
	 */
	public static function defaults() {
		return array(
			'brand'        => 'BuyMore',
			'orders'       => '37',
			'orders_label' => 'Last 7 days',
			'user_name'    => 'Ryana',
			'cart_label'   => 'Cart',
			'cart_extra'   => '+8',
			'explore_title'=> 'Explore',
			'menu'         => "Popular Products|#\n*Explore New|#\nClothing and Shoes|#\nGifts and Living|#\nInspiration|#",
			'quick'        => "Request for product|#\nAdd member|#",
			'last_orders'  => "DXC Nike...|#\nOuterwear...|#",
			'logout_label' => 'Log out',
			'logout_url'   => '#',
		);
	}

	public static function get_all() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	public static function get( $key ) {
		$all = self::get_all();
		return isset( $all[ $key ] ) ? $all[ $key ] : '';
	}

	/**
	 * Parse "Label|url" lines. A leading * marks the active item.
	 *
	 * @return array[] Each: label, url, active.
	 */
	public static function parse_lines( $text ) {
		$items = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$active = false;
			if ( '*' === $line[0] ) {
				$active = true;
				$line   = ltrim( $line, '* ' );
			}
			$parts   = array_map( 'trim', explode( '|', $line, 2 ) );
			$items[] = array(
				'label'  => $parts[0],
				'url'    => isset( $parts[1] ) && '' !== $parts[1] ? $parts[1] : '#',
				'active' => $active,
			);
		}
		return $items;
	}

	/* ---------- Admin page ---------- */

	public static function add_menu() {
		add_submenu_page(
			'edit.php?post_type=bm_card',
			__( 'BuyMore Settings', 'buymore' ),
			__( 'Settings', 'buymore' ),
			'manage_options',
			'buymore-settings',
			array( __CLASS__, 'render_page' )
		);
	}

	public static function register() {
		register_setting(
			'buymore_group',
			self::OPTION,
			array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) )
		);
	}

	public static function sanitize( $input ) {
		$input    = is_array( $input ) ? $input : array();
		$defaults = self::defaults();
		$clean    = array();

		$text_fields = array( 'brand', 'orders', 'orders_label', 'user_name', 'cart_label', 'cart_extra', 'explore_title', 'logout_label' );
		foreach ( $text_fields as $key ) {
			$clean[ $key ] = isset( $input[ $key ] ) ? sanitize_text_field( $input[ $key ] ) : $defaults[ $key ];
		}
		foreach ( array( 'menu', 'quick', 'last_orders' ) as $key ) {
			$clean[ $key ] = isset( $input[ $key ] ) ? sanitize_textarea_field( $input[ $key ] ) : $defaults[ $key ];
		}
		$clean['logout_url'] = isset( $input['logout_url'] ) ? esc_url_raw( $input['logout_url'] ) : '#';
		if ( '' === $clean['logout_url'] ) {
			$clean['logout_url'] = '#';
		}
		return $clean;
	}

	private static function text_row( $key, $label, $values ) {
		printf(
			'<tr><th scope="row"><label for="bm_%1$s">%2$s</label></th><td><input type="text" class="regular-text" id="bm_%1$s" name="%3$s[%1$s]" value="%4$s"></td></tr>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( self::OPTION ),
			esc_attr( $values[ $key ] )
		);
	}

	private static function area_row( $key, $label, $help, $values ) {
		printf(
			'<tr><th scope="row"><label for="bm_%1$s">%2$s</label></th><td><textarea class="large-text code" rows="5" id="bm_%1$s" name="%3$s[%1$s]">%4$s</textarea><p class="description">%5$s</p></td></tr>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( self::OPTION ),
			esc_textarea( $values[ $key ] ),
			esc_html( $help )
		);
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$v = self::get_all();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'BuyMore Dashboard Settings', 'buymore' ); ?></h1>
			<p><?php esc_html_e( 'Use the shortcode [buymore_dashboard] on any page, or choose the page template "BuyMore Dashboard (Full Page)".', 'buymore' ); ?></p>
			<form method="post" action="options.php">
				<?php settings_fields( 'buymore_group' ); ?>
				<table class="form-table" role="presentation">
					<?php
					self::text_row( 'brand', __( 'Brand name', 'buymore' ), $v );
					self::text_row( 'orders', __( 'Orders count', 'buymore' ), $v );
					self::text_row( 'orders_label', __( 'Orders caption', 'buymore' ), $v );
					self::text_row( 'explore_title', __( 'Section title', 'buymore' ), $v );
					self::text_row( 'user_name', __( 'User name', 'buymore' ), $v );
					self::text_row( 'cart_label', __( 'Cart label', 'buymore' ), $v );
					self::text_row( 'cart_extra', __( 'Cart badge', 'buymore' ), $v );
					self::area_row( 'menu', __( 'Sidebar menu', 'buymore' ), __( 'One item per line: Label|URL. Prefix a line with * to mark it active.', 'buymore' ), $v );
					self::area_row( 'quick', __( 'Quick actions', 'buymore' ), __( 'One per line: Label|URL', 'buymore' ), $v );
					self::area_row( 'last_orders', __( 'Last orders', 'buymore' ), __( 'One per line: Title|URL', 'buymore' ), $v );
					self::text_row( 'logout_label', __( 'Logout label', 'buymore' ), $v );
					self::text_row( 'logout_url', __( 'Logout URL', 'buymore' ), $v );
					?>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
