<?php
/**
 * Shortcode, data preparation, asset loading and full-page template.
 *
 * @package BuyMore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BuyMore_Shortcode {

	const TEMPLATE_SLUG = 'buymore-fullpage';

	public static function init() {
		add_shortcode( 'buymore_dashboard', array( __CLASS__, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_filter( 'theme_page_templates', array( __CLASS__, 'register_template' ) );
		add_filter( 'template_include', array( __CLASS__, 'load_template' ) );
	}

	/* ---------- Page template (no theme header/footer) ---------- */

	public static function register_template( $templates ) {
		$templates[ self::TEMPLATE_SLUG ] = __( 'BuyMore Dashboard (Full Page)', 'buymore' );
		return $templates;
	}

	public static function load_template( $template ) {
		if ( is_singular( 'page' ) && get_page_template_slug() === self::TEMPLATE_SLUG ) {
			return BUYMORE_DIR . 'templates/page-fullpage.php';
		}
		return $template;
	}

	/* ---------- Assets ---------- */

	public static function is_dashboard_request() {
		if ( ! is_singular() ) {
			return false;
		}
		$post = get_post();
		if ( ! $post ) {
			return false;
		}
		return has_shortcode( $post->post_content, 'buymore_dashboard' )
			|| get_page_template_slug( $post ) === self::TEMPLATE_SLUG;
	}

	public static function enqueue() {
		if ( ! self::is_dashboard_request() ) {
			return;
		}
		wp_enqueue_style(
			'buymore-font',
			'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
			array(),
			null
		);
		wp_enqueue_style( 'buymore', BUYMORE_URL . 'assets/css/buymore.css', array( 'buymore-font' ), BUYMORE_VERSION );
		wp_enqueue_script( 'buymore', BUYMORE_URL . 'assets/js/buymore.js', array(), BUYMORE_VERSION, true );
	}

	/* ---------- Data ---------- */

	/**
	 * Image URL: featured image, or a bundled placeholder as fallback.
	 */
	private static function image_url( $post_id, $index ) {
		$url = get_the_post_thumbnail_url( $post_id, 'large' );
		if ( $url ) {
			return $url;
		}
		$n = ( $index % 6 ) + 1;
		return BUYMORE_URL . 'assets/img/placeholder-' . $n . '.svg';
	}

	/**
	 * Edit link, only for users who may edit this item (used for front-end "Edit" buttons).
	 */
	private static function edit_link( $post_id ) {
		return current_user_can( 'edit_post', $post_id ) ? (string) get_edit_post_link( $post_id, 'raw' ) : '';
	}

	private static function genders( $post_id ) {
		$terms = get_the_terms( $post_id, 'bm_gender' );
		if ( ! $terms || is_wp_error( $terms ) ) {
			return '';
		}
		return implode( ' ', wp_list_pluck( $terms, 'slug' ) );
	}

	private static function query( $type, $limit = 24 ) {
		return new WP_Query(
			array(
				'post_type'      => $type,
				'post_status'    => 'publish',
				'posts_per_page' => $limit,
				'orderby'        => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
				'no_found_rows'  => true,
			)
		);
	}

	/**
	 * @return array[] Cards grouped by slot.
	 */
	public static function get_cards() {
		$grouped = array();
		$query   = self::query( 'bm_card' );
		$i       = 0;
		foreach ( $query->posts as $post ) {
			$slot = get_post_meta( $post->ID, '_bm_slot', true );
			$slot = $slot ? $slot : 'feature';
			$bg   = sanitize_hex_color( (string) get_post_meta( $post->ID, '_bm_bg', true ) );
			$fg   = sanitize_hex_color( (string) get_post_meta( $post->ID, '_bm_text', true ) );

			$grouped[ $slot ][] = array(
				'id'       => $post->ID,
				'title'    => get_the_title( $post ),
				'subtitle' => get_post_meta( $post->ID, '_bm_subtitle', true ),
				'button'   => get_post_meta( $post->ID, '_bm_button', true ),
				'link'     => get_post_meta( $post->ID, '_bm_link', true ),
				'bg'       => $bg ? $bg : '#ffffff',
				'fg'       => $fg ? $fg : '#111111',
				'image'    => self::image_url( $post->ID, $i ),
				'gender'   => self::genders( $post->ID ),
				'edit'     => self::edit_link( $post->ID ),
			);
			$i++;
		}
		wp_reset_postdata();
		return $grouped;
	}

	/**
	 * @return array[] Products.
	 */
	public static function get_products( $limit = 24 ) {
		$products = array();
		$query    = self::query( 'bm_product', $limit );
		$i        = 2;
		foreach ( $query->posts as $post ) {
			$price  = (string) get_post_meta( $post->ID, '_bm_price', true );
			$colors = array_filter(
				array_map(
					'sanitize_hex_color',
					array_map( 'trim', explode( ',', (string) get_post_meta( $post->ID, '_bm_colors', true ) ) )
				)
			);

			$products[] = array(
				'id'     => $post->ID,
				'title'  => get_the_title( $post ),
				'label'  => get_post_meta( $post->ID, '_bm_label', true ),
				'price'  => $price,
				'amount' => (float) preg_replace( '/[^0-9.]/', '', $price ),
				'colors' => array_values( $colors ),
				'link'   => get_post_meta( $post->ID, '_bm_link', true ),
				'fav'    => '1' === get_post_meta( $post->ID, '_bm_favourite', true ),
				'image'  => self::image_url( $post->ID, $i ),
				'gender' => self::genders( $post->ID ),
				'edit'   => self::edit_link( $post->ID ),
			);
			$i++;
		}
		wp_reset_postdata();
		return $products;
	}

	/* ---------- Render ---------- */

	/**
	 * Shortcode callback.
	 *
	 * Attributes: title (section heading override), products (max products shown).
	 * Example: [buymore_dashboard title="Winter Sale" products="4"]
	 */
	public static function render( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'title'    => '',
				'products' => 24,
			),
			$atts,
			'buymore_dashboard'
		);

		// Make sure assets exist when the shortcode is used outside the normal content (e.g. widgets).
		if ( ! wp_style_is( 'buymore', 'enqueued' ) ) {
			self::enqueue_forced();
		}

		$settings = BuyMore_Settings::get_all();
		if ( '' !== trim( (string) $atts['title'] ) ) {
			$settings['explore_title'] = sanitize_text_field( $atts['title'] );
		}
		$cards      = self::get_cards();
		$products   = self::get_products( max( 1, absint( $atts['products'] ) ) );
		$favourites = array_values( array_filter( $products, static function ( $p ) {
			return $p['fav'];
		} ) );

		ob_start();
		include BUYMORE_DIR . 'templates/dashboard.php';
		return ob_get_clean();
	}

	private static function enqueue_forced() {
		wp_enqueue_style( 'buymore-font', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap', array(), null );
		wp_enqueue_style( 'buymore', BUYMORE_URL . 'assets/css/buymore.css', array( 'buymore-font' ), BUYMORE_VERSION );
		wp_enqueue_script( 'buymore', BUYMORE_URL . 'assets/js/buymore.js', array(), BUYMORE_VERSION, true );
	}
}
