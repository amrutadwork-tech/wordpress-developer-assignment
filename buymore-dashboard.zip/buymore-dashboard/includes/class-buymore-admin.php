<?php
/**
 * Editor-friendly helpers: shortcuts to the content screens from the page editor,
 * the front-end admin bar and the Plugins list.
 *
 * @package BuyMore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BuyMore_Admin {

	public static function init() {
		add_action( 'add_meta_boxes_page', array( __CLASS__, 'add_page_meta_box' ) );
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 90 );
		add_filter( 'plugin_action_links_' . plugin_basename( BUYMORE_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Shortcuts to every place where dashboard content is managed.
	 *
	 * @return array[] Each: label, url.
	 */
	public static function links() {
		$links = array(
			array( __( 'Edit promo cards', 'buymore' ), admin_url( 'edit.php?post_type=bm_card' ) ),
			array( __( 'Edit products', 'buymore' ), admin_url( 'edit.php?post_type=bm_product' ) ),
			array( __( 'Add new card', 'buymore' ), admin_url( 'post-new.php?post_type=bm_card' ) ),
			array( __( 'Add new product', 'buymore' ), admin_url( 'post-new.php?post_type=bm_product' ) ),
		);
		if ( current_user_can( 'manage_options' ) ) {
			$links[] = array( __( 'Dashboard settings (menu, orders, user)', 'buymore' ), admin_url( 'edit.php?post_type=bm_card&page=buymore-settings' ) );
		}
		return $links;
	}

	/* ---------- Page editor box ---------- */

	public static function add_page_meta_box( $post ) {
		$uses_dashboard = has_shortcode( $post->post_content, 'buymore_dashboard' )
			|| get_page_template_slug( $post ) === BuyMore_Shortcode::TEMPLATE_SLUG;
		if ( ! $uses_dashboard ) {
			return;
		}
		add_meta_box(
			'buymore_page_help',
			__( 'BuyMore dashboard content', 'buymore' ),
			array( __CLASS__, 'render_page_meta_box' ),
			'page',
			'side',
			'high'
		);
	}

	public static function render_page_meta_box() {
		echo '<p>' . esc_html__( 'This page shows the dashboard through the [buymore_dashboard] shortcode. The cards, products and menus are managed here:', 'buymore' ) . '</p><ul style="list-style:disc;padding-left:18px">';
		foreach ( self::links() as $link ) {
			printf( '<li><a href="%s" target="_blank" rel="noopener">%s</a></li>', esc_url( $link[1] ), esc_html( $link[0] ) );
		}
		echo '</ul><p class="description">' . esc_html__( 'Shortcode options: [buymore_dashboard title="Explore" products="8"]', 'buymore' ) . '</p>';
	}

	/* ---------- Front-end admin bar ---------- */

	public static function admin_bar( $bar ) {
		if ( is_admin() || ! current_user_can( 'edit_posts' ) || ! BuyMore_Shortcode::is_dashboard_request() ) {
			return;
		}
		$bar->add_node(
			array(
				'id'    => 'buymore',
				'title' => __( 'BuyMore Dashboard', 'buymore' ),
				'href'  => admin_url( 'edit.php?post_type=bm_card' ),
			)
		);
		foreach ( self::links() as $i => $link ) {
			$bar->add_node(
				array(
					'id'     => 'buymore-' . $i,
					'parent' => 'buymore',
					'title'  => $link[0],
					'href'   => $link[1],
				)
			);
		}
	}

	/* ---------- Plugins screen ---------- */

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'edit.php?post_type=bm_card' ) ) . '">' . esc_html__( 'Manage content', 'buymore' ) . '</a>' );
		return $links;
	}
}
