<?php
/**
 * Plugin Name: BuyMore Dashboard
 * Description: Fashion e-commerce dashboard page built with custom code (no page builder). Content is managed through Custom Post Types, meta boxes and a settings page. Use the [buymore_dashboard] shortcode or the "BuyMore Dashboard (Full Page)" page template.
 * Version:     1.0.0
 * Author:      Amruta
 * Text Domain: buymore
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BUYMORE_VERSION', '1.0.0' );
define( 'BUYMORE_FILE', __FILE__ );
define( 'BUYMORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'BUYMORE_URL', plugin_dir_url( __FILE__ ) );

require_once BUYMORE_DIR . 'includes/class-buymore-settings.php';
require_once BUYMORE_DIR . 'includes/class-buymore-post-types.php';
require_once BUYMORE_DIR . 'includes/class-buymore-shortcode.php';
require_once BUYMORE_DIR . 'includes/class-buymore-installer.php';
require_once BUYMORE_DIR . 'includes/class-buymore-admin.php';

register_activation_hook( __FILE__, array( 'BuyMore_Installer', 'activate' ) );

add_action(
	'plugins_loaded',
	static function () {
		BuyMore_Settings::init();
		BuyMore_Post_Types::init();
		BuyMore_Shortcode::init();
		BuyMore_Admin::init();
	}
);
